import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
 


def graph2():
    df = pd.read_csv('matches.csv')

    st.subheader('IPL Team Wins Analysis')

    selected_year = st.selectbox('Select Year', df['season'].unique())

    filtered_data = df[df['season'] == selected_year]

    team_wins = filtered_data['winner'].value_counts()

    fig, ax = plt.subplots(figsize=(10, 6))
    colors = sns.color_palette("Set2", n_colors=len(team_wins))
    sns.barplot(x=team_wins.index, y=team_wins.values, ax=ax, palette=colors)
    plt.xlabel('Teams')
    plt.ylabel('Number of Wins')
    plt.title(f'IPL Team Wins in {selected_year}')
    ax.yaxis.grid(True)
    for i, value in enumerate(team_wins):
        ax.text(i, value + 0.1, str(value), ha='center', va='bottom')
    plt.xticks(rotation=45)
    st.pyplot(fig)
    
    

    
    
