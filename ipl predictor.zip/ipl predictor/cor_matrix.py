import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

@st.cache
def load_data():
    return pd.read_csv('winnerlist.csv')

def create_bar_plot(data, selected_year):
    all_teams = ['Royal Challengers Bangalore', 'Chennai Super Kings', 'Kolkata Knight Rider', 'Delhi Capitals', 'Rajasthan Royals', 'Sunrisers Hyderabad', 'Kings XI Punjab', 'Gujarat Titans']
    
    team_counts = data[data['Year'] <= selected_year]['Team'].value_counts()

    for team in all_teams:
        if team not in team_counts:
            team_counts[team] = 0

    team_counts = team_counts.sort_index()

    fig, ax = plt.subplots(figsize=(13, 6))
    colors = sns.color_palette("viridis", len(team_counts))

    sns.barplot(x=team_counts.index, y=team_counts.values, ax=ax, palette=colors)
    ax.set_xlabel('Team')
    ax.set_ylabel('Victory Count')
    ax.set_title(f'Total IPL Team Victory Count up to {selected_year}')
    ax.tick_params(axis='x', rotation=45)

    for i, value in enumerate(team_counts.values):
        ax.text(i, value + 0.1, str(value), ha='center', va='bottom', fontsize=8)

    ax.grid(axis='y', linestyle='--', alpha=0.7)

    st.pyplot(fig)



def main():
    st.subheader('Total IPL Team Victory Count Bar Graph')

    data = load_data()

    available_years = sorted(data['Year'].unique())
    selected_year = st.selectbox('Select Year', available_years)

    create_bar_plot(data, selected_year)

    

if __name__ == "_main_":
    main()