import streamlit as st
import math
import numpy as np
import pickle
import pandas as pd
import matplotlib.pyplot as plt
from project_1 import score_prob
from project import win_prob
from graph import maint,load_data,create_bar_plot
from grp2 import graph2


def main():
    st.markdown(
            f"""
            <style>
            .stApp {{
                background-image: url("https://www.pngmagic.com/product_images/cool-solid-color-backgrounds.jpg");
                background-attachment: fixed;
                background-size: cover
            }}
            </style>
            """,
            unsafe_allow_html=True
        )
    st.title('IPL Probability')
    st.write(
        "Welcome to the IPL Probability Project! This project aims to analyze and predict outcomes in IPL matches using Machine learning."
    )

    
    page = st.sidebar.radio("Options", ["Home", "Win predictor", "Score Predictor"])

    if page == "Home":
        show_home_page()
    elif page == "Win predictor":
        show_win_page()
    elif page == "Score Predictor":
        show_score_page()

def show_home_page():
    st.header("About the Project")
    st.write(
        "This project utilizes statistical and machine learning techniques to explore the probabilities of different events in IPL matches."
    )
    maint()
    graph2()


def show_win_page():
    st.header("Win predictor")
    st.write(
        "Perform in-depth analysis of past IPL matches to derive insights into match outcomes."
    )
    win_prob()
    

def show_score_page():
    st.markdown("<h1 style='text-align: center; color: white;'> IPL Score Predictor 2022 </h1>", unsafe_allow_html=True)
    st.write(
        "Perform in-depth analysis of past IPL matches to derive insights into match score."
    )
    with st.expander("Description"):
        st.info("""A Simple ML Model to predict IPL Scores between teams in an ongoing match. To make sure the model results accurate score and some reliability the minimum no. of current overs considered is greater than 5 overs.
        
    """)
    score_prob()
    

if __name__ == "__main__":
    main()
